const express = require('express');
const costumer = require('../models/customer');
const router = express.Router();

// get all customers
router.get("/customers", async (req, res) => {
    try{
        const customers = await costumer.find();
        res.json(customers);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

//get customer by id
router.get("/customers/:id", async (req, res) => {
    try{
        const customerObejct = await costumer.findOne({ id: req.params.id });
        if(customerObejct == null) {
            return res.status(400).json(404);
        }else {
            res.json(customerObejct);
        }
    }catch (error) {
        res.status(500).json({ message: error.message });
    }
});
//Create/Insert a one customer
router.post('/customer', async (req, res) => {
    const customerObejct = new costumer({
        id: req.body.id,
        name: req.body.name,
        age: req.body.age,
        moneySpent: req.body.moneySpent
    });
    try{
        const customerToSave = await customerObejct.save();
        res.status(200).json(customerToSave);
    }catch (error) {
        res.status(500).json({ message: error.message });
    }
});

//Calculate the money spent by a customer + money spent in a week 
router.get('/customers/:id/:moneySpent', async (req, res) => {
    try {
        const customerObejct = await costumer.findOne({ id: req.params.id });
        if (!customerObejct) {
            return res.status(400).json(404);
        }
        const moneySpent = customerObejct.moneySpent * 7;
        res.json({ moneySpent: moneySpent });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});
module.exports = router;