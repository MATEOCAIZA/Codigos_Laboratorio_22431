const express = require('express');
const costumer = require('../models/vinylRecord');
const router = express.Router();

router.get("/vinylRecords", async (req, res) => {
    try {
        const vinylRecords = await costumer.find();
        res.json(vinylRecords);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.get("/vinylRecords/:serialNumber", async (req, res) => {
    try {
        const vinylRecordObject = await costumer.findOne({ serialNumber: req.params.serialNumber });
        if (vinylRecordObject == null) {
            return res.status(404).json({ message: "Vinyl record not found" });
        } else {
            res.json(vinylRecordObject);
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.post('/vinylRecord', async (req, res) => {
    const vinylRecordObject = new costumer({
        serialNumber: req.body.serialNumber,
        brand: req.body.brand,
        model: req.body.model,
        Price: req.body.Price,
        itsNew: req.body.itsNew,
        specialEdition: req.body.specialEdition,
        year: req.body.year
    });
    try {
        const vinylRecordToSave = await vinylRecordObject.save();
        res.status(201).json(vinylRecordToSave);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
