const port = 3010;

const express = require('express');
const app = express();
const mongoose = require('mongoose');

mongoose.connect(`mongodb+srv://msllumigusin:vCcmi4WKrmdvIAb8@cluster0.yxgzkmj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`, {
    useNewUrlParser: true});

const db = mongoose.connection;

db.on("error",(error) => crossOriginIsolated.error(error));
db.once("open", () => console.log("System connected to MongoDB Database"));

app.use(express.json());

const customerRouter = require('./routes/customerRoutes');
const vinylRecordRouter = require('./routes/vinylRecordRoutes');

app.use("/vinylRecords", vinylRecordRouter);

app.use("/computerstore", customerRouter);

app.listen(port, () => console.log(`My computers store server is running on port --> ${port}`));
