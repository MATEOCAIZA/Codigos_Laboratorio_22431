const mongoose = require('mongoose');

const vinylRecordSchema = new mongoose.Schema({
    serialNumber: {type: Number},
    brand: {type: String},
    model: {type: String},
    Price: {type: Number},
    itsNew: {type: String},
    specialEdition: {type: String},
    year: {type: Number},
}, { collection: 'VinylRecord' }
);


module.exports = mongoose.model('VinylRecord', vinylRecordSchema);